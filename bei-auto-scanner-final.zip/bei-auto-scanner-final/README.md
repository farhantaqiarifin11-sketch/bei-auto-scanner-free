# BEI Auto Scanner — Paket dasar

## Instalasi
1. Unggah seluruh isi folder ini ke repository GitHub.
2. Aktifkan Actions dan izinkan workflow membuat commit (`Settings > Actions > General > Workflow permissions > Read and write permissions`).
3. Tambahkan repository secrets:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID`
4. Isi `data/universe/idx-tickers.csv` dengan kolom `ticker`, berisi kode saham BEI (contoh `BBCA`, `BMRI`). Daftar ticker harus diperbarui secara berkala.
5. Jalankan workflow `BEI Auto Scanner` secara manual untuk pengujian.

## Batasan yang harus diketahui
- Data harga menggunakan Yahoo Finance (`.JK`), bukan feed BEI real-time/orderbook.
- Endpoint IDX dapat menolak akses otomatis. Jika demikian, file CSV universe lokal wajib disediakan. Sistem tidak mengklaim telah memindai saham yang tidak ada di daftar tersebut.
- Fundamental Yahoo Finance tidak lengkap untuk sebagian emiten; data kosong ditandai tidak tersedia.
- Polling Telegram menggunakan GitHub Actions, sehingga respons tidak instan dan dapat terlambat.
- Perintah `/scan`, `/top10`, dan `/analyze` pada paket dasar hanya memberi respons status/petunjuk; analisis on-demand belum diimplementasikan.
- Entry/target/stop-loss merupakan estimasi persentase sederhana, bukan hasil analisis support/resistance adaptif.
- Evaluasi jurnal merupakan evaluasi harga sederhana; target pertama yang tersentuh ditandai selesai sehingga evaluasi target kedua memerlukan pengembangan lanjutan.
- Skor teknikal belum dibacktest. Jangan menganggap skor sebagai probabilitas profit.
- Gunakan akun demo/paper trading dan verifikasi data sebelum mengambil keputusan.
