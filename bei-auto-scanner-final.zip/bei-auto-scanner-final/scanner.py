import os, json, logging, time
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import requests, pandas as pd, yfinance as yf
from technical_engine import enrich, detect_patterns, score_stock
from risk_management import trade_levels
from fundamental_engine import get_fundamentals
from signal_evaluation import record_signal, evaluate_open_signals, summary
from bot_commands import send

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
CFG=json.loads(Path("config.json").read_text())
TZ=ZoneInfo(CFG.get("market_timezone","Asia/Jakarta"))
DATA=Path("data"); DATA.mkdir(exist_ok=True)

def telegram(text):
    chat=os.getenv("TELEGRAM_CHAT_ID","").strip()
    if chat: send(chat,text)

def universe():
    local=DATA/"universe/idx-tickers.csv"
    if local.exists():
        df=pd.read_csv(local)
        col=next((c for c in ("ticker","code","symbol") if c in df.columns),None)
        if col:
            vals=df[col].dropna().astype(str).str.upper().tolist()
            return [x if x.endswith(".JK") else x+".JK" for x in vals][:int(CFG["max_tickers"])]
    # IDX endpoint may block automated access; do not silently claim full coverage.
    try:
        r=requests.get(CFG["universe_url"],headers={"User-Agent":"Mozilla/5.0"},timeout=20)
        r.raise_for_status()
        payload=r.json()
        rows=payload.get(" data",payload.get("data",[])) if isinstance(payload,dict) else payload
        found=[]
        for row in rows:
            code=row.get(" kodeEmiten") or row.get("KodeEmiten") or row.get("code")
            if code: found.append(str(code).upper()+".JK")
        if found: return found[:int(CFG["max_tickers"])]
    except Exception as e:
        logging.warning("Universe IDX tidak tersedia: %s",type(e).__name__)
    raise RuntimeError("Universe saham tidak tersedia. Isi data/universe/idx-tickers.csv dengan daftar ticker BEI yang valid.")

def fetch_frame(ticker):
    try:
        df=yf.download(ticker,period="5d",interval="5m",progress=False,auto_adjust=False,threads=False)
        if isinstance(df.columns,pd.MultiIndex): df.columns=df.columns.get_level_values(0)
        return df.dropna()
    except Exception as e:
        logging.warning("%s gagal diunduh: %s",ticker,type(e).__name__)
        return pd.DataFrame()

def analyze(ticker):
    raw=fetch_frame(ticker)
    df=enrich(raw)
    if df is None: return None
    last=df.iloc[-1]; price=float(last.Close)
    if price < float(CFG["min_price_idr"]): return None
    value=(df.Close*df.Volume).tail(50).mean()
    if pd.isna(value) or value < float(CFG["min_avg_value_idr"])/78: return None
    patterns=detect_patterns(df); score=score_stock(df,patterns)
    if score < int(CFG["min_score"]): return None
    levels=trade_levels(price,CFG)
    result={"ticker":ticker.replace(".JK",""),"price":round(price,2),"score":score,
            "rsi":round(float(last.RSI),1),"rvol":round(float(last.RVOL),2) if pd.notna(last.RVOL) else None,
            "vwap":round(float(last.VWAP),2) if pd.notna(last.VWAP) else None,
            "patterns":patterns,**levels}
    if CFG.get("fundamental_enabled"):
        result["fundamental"]=get_fundamentals(ticker)
    return result

def mode_now(now):
    t=now.hour*60+now.minute
    if 360 <= t < 365: return "TOP10"
    if 520 <= t < 525: return "PREOPEN"
    if 555 <= t < 560: return "MOMENTUM"
    if 540 <= t <= 940 and t%20 < 5: return "ROUTINE"
    return "ROUTINE"

def main():
    now=datetime.now(TZ); mode=mode_now(now)
    tickers=universe(); logging.info("Universe tersedia: %d ticker",len(tickers))
    results=[]; scanned=0
    for i,ticker in enumerate(tickers):
        item=analyze(ticker); scanned+=1
        if item: results.append(item)
        if (i+1)%50==0: logging.info("Progres %d/%d",i+1,len(tickers))
        time.sleep(0.05)
    results.sort(key=lambda x:x["score"],reverse=True)
    selected=results[:int(CFG["max_alerts"])]
    lines=[f"<b>BEI AUTO SCANNER — {mode}</b>",f"Waktu: {now:%Y-%m-%d %H:%M} WIB",f"Universe: {len(tickers)} | Dipindai: {scanned} | Kandidat: {len(results)}"]
    for x in selected:
        p=x["patterns"]; tags=", ".join(k.upper() for k,v in p.items() if v) or "konfirmasi teknikal"
        lines.append(f"\\n<b>{x['ticker']}</b> | Skor {x['score']}/100 | Harga {x['price']:.2f}\\nRSI {x['rsi']} | RVOL {x['rvol']} | VWAP {x['vwap']}\\nPola: {tags}\\nEntry {x['entry_low']}-{x['entry_high']} | SL {x['stop_loss']} | TP1 {x['target_1']} | TP2 {x['target_2']}")
        record_signal({"ticker":x["ticker"]+".JK","entry":x["price"],"stop_loss":x["stop_loss"],"target_1":x["target_1"],"target_2":x["target_2"],"status":"OPEN","created_at":now.isoformat()})
    if not selected: lines.append("Tidak ada kandidat yang memenuhi filter. Ini bukan berarti tidak ada saham bergerak.")
    lines.append("\\nCatatan: data Yahoo Finance dapat tertunda/tidak lengkap. Estimasi bukan rekomendasi atau jaminan transaksi.")
    telegram("\\n".join(lines))
    def price_lookup(t):
        d=fetch_frame(t); return float(d.Close.iloc[-1]) if not d.empty else None
    if CFG.get("evaluation_enabled"):
        evaluate_open_signals(price_lookup)
        logging.info("Evaluasi sinyal: %s",summary())

if __name__=="__main__":
    if not os.getenv("TELEGRAM_BOT_TOKEN") or not os.getenv("TELEGRAM_CHAT_ID"):
        raise SystemExit("Secrets TELEGRAM_BOT_TOKEN dan TELEGRAM_CHAT_ID wajib diatur.")
    main()
