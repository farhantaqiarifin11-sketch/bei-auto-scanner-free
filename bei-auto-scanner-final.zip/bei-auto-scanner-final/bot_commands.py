import os, json, requests
from pathlib import Path

API = "https://api.telegram.org/bot{}/{}"
STATE = Path("data/telegram_state.json")

def telegram(method, payload):
    token = os.getenv("TELEGRAM_BOT_TOKEN","").strip()
    if not token: return None
    r = requests.post(API.format(token, method), json=payload, timeout=25)
    r.raise_for_status()
    data = r.json()
    if not data.get("ok"): raise RuntimeError(data)
    return data.get("result")

def send(chat_id, text):
    return telegram("sendMessage", {"chat_id":chat_id,"text":text,"parse_mode":"HTML"})

def load_offset():
    try: return int(json.loads(STATE.read_text()).get("offset",0))
    except Exception: return 0

def save_offset(offset):
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps({"offset":offset}))

def handle(text, chat_id):
    cmd = (text or "").strip()
    if cmd.startswith("/start") or cmd.startswith("/help"):
        send(chat_id, "BEI AUTO SCANNER\\nPerintah: /status, /top10, /scan, /watchlist, /add KODE, /remove KODE, /analyze KODE, /performance")
    elif cmd.startswith("/status"):
        send(chat_id, "Bot aktif jika workflow GitHub Actions berjalan. Data harga dapat tertunda dan bukan feed real-time.")
    elif cmd.startswith("/top10") or cmd.startswith("/scan"):
        send(chat_id, "Permintaan diterima. Hasil scan dikirim oleh workflow pemindaian terjadwal; pemindaian on-demand belum diaktifkan pada paket dasar.")
    elif cmd.startswith("/watchlist"):
        p=Path("data/watchlist.json")
        items=json.loads(p.read_text()) if p.exists() else []
        send(chat_id, "Watchlist: " + (", ".join(items) if items else "kosong"))
    elif cmd.startswith("/add "):
        ticker=cmd.split(maxsplit=1)[1].upper().replace(".JK","")
        p=Path("data/watchlist.json"); p.parent.mkdir(parents=True,exist_ok=True)
        items=json.loads(p.read_text()) if p.exists() else []
        if ticker not in items: items.append(ticker)
        p.write_text(json.dumps(items,indent=2)); send(chat_id,f"{ticker} ditambahkan ke watchlist.")
    elif cmd.startswith("/remove "):
        ticker=cmd.split(maxsplit=1)[1].upper().replace(".JK","")
        p=Path("data/watchlist.json"); items=json.loads(p.read_text()) if p.exists() else []
        items=[x for x in items if x != ticker]; p.write_text(json.dumps(items,indent=2))
        send(chat_id,f"{ticker} dihapus dari watchlist.")
    elif cmd.startswith("/analyze "):
        send(chat_id,"Analisis on-demand belum terhubung pada paket dasar. Gunakan hasil pemindaian terjadwal.")
    elif cmd.startswith("/performance"):
        from signal_evaluation import summary
        s=summary(); send(chat_id,f"Total sinyal: {s['total']}\\nSelesai: {s['closed']}\\nWin rate: {s['win_rate_pct']}%")
    else:
        send(chat_id,"Perintah tidak dikenal. Ketik /help.")

def poll():
    token=os.getenv("TELEGRAM_BOT_TOKEN","").strip()
    owner=os.getenv("TELEGRAM_CHAT_ID","").strip()
    if not token or not owner: raise RuntimeError("TELEGRAM_BOT_TOKEN/TELEGRAM_CHAT_ID belum diatur.")
    offset=load_offset()
    updates=telegram("getUpdates",{"offset":offset,"timeout":5,"allowed_updates":["message"]}) or []
    max_id=offset
    for u in updates:
        max_id=max(max_id,u["update_id"]+1)
        msg=u.get("message",{}); chat=msg.get("chat",{})
        if str(chat.get("id")) != owner: continue
        handle(msg.get("text",""), str(chat["id"]))
    if max_id != offset: save_offset(max_id)
    print(f"Telegram updates diproses: {len(updates)}")

if __name__ == "__main__":
    poll()
