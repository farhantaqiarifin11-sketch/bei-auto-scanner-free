# BEI Auto Scanner — Final Free (GitHub Actions + Telegram)

## Isi paket
Ekstrak ZIP ini. Unggah **isi folder hasil ekstraksi** ke root repository GitHub, bukan file ZIP-nya. File `scanner.py`, `bot_commands.py`, `config.json`, `requirements.txt`, folder `data/`, dan folder `.github/` harus langsung terlihat di halaman Code repository. Jangan sampai seluruh isi berada di dalam folder pembungkus tambahan.

## GitHub Secrets
Atur di Settings → Secrets and variables → Actions → Repository secrets:
- `TELEGRAM_BOT_TOKEN`: token bot dari BotFather.
- `TELEGRAM_CHAT_ID`: ID chat numerik milik akun/grup yang diizinkan menerima perintah. Jangan unggah token ke repository atau kirim token di chat.

## Menjalankan
1. Ganti file/folder lama dengan seluruh isi paket ini. Pastikan `.github/workflows/scan.yml` dan `.github/workflows/telegram_commands.yml` ikut terganti.
2. Buka Actions → Telegram Commands → Run workflow.
3. Kirim `/start` ke bot Telegram. Tunggu workflow selesai; jadwal polling berjalan setiap 10 menit pada hari kerja sesuai cron.
4. Uji `/help`, `/status`, lalu `/top10` atau `/scan`.
5. Jalankan workflow **BEI Auto Scanner** secara manual untuk menguji pemindaian.

## Perintah Telegram
- `/start` atau `/help` — daftar perintah
- `/status` — status bot
- `/top10` atau `/scan` — pemindaian on-demand
- `/analyze KODE` — analisis satu saham, contoh `/analyze BBCA`
- `/watchlist` — tampilkan watchlist
- `/add KODE` dan `/remove KODE` — kelola watchlist
- `/performance` — ringkasan evaluasi sinyal

## Catatan penting
- Data harga memakai Yahoo Finance melalui yfinance; dapat tertunda, tidak lengkap, dan bukan data real-time/orderbook.
- Universe IDX dapat gagal diakses; dalam kondisi itu scanner memakai fallback terbatas, bukan seluruh saham BEI.
- Fundamental bersifat best-effort dan harus diverifikasi pada laporan resmi emiten.
- GitHub Actions terjadwal dapat terlambat atau tidak berjalan seketika. Perintah Telegram diproses ketika workflow Telegram Commands berjalan.
- Ini alat penyaring informasi, bukan rekomendasi beli/jual atau jaminan keuntungan.
