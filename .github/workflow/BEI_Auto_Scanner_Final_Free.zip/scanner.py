import os, json, time, re, math, traceback
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd
import requests
import yfinance as yf

ROOT = Path(__file__).resolve().parent
CFG_PATH = ROOT / "config.json"
if not CFG_PATH.exists():
    raise FileNotFoundError("config.json tidak ditemukan. Salin config.json.example menjadi config.json dan isi universe_url.")
CFG = json.loads(CFG_PATH.read_text(encoding="utf-8"))
TZ = ZoneInfo(CFG.get("market_timezone", "Asia/Jakarta"))
STATE_PATH = ROOT / "data" / "last_alerts.json"
FUND_CACHE_PATH = ROOT / "data" / "fundamental_cache.json"

DEFAULTS = {
    "min_score": 65, "max_alerts": 10, "max_tickers": 1000,
    "batch_size": 35, "min_price_idr": 50,
    "min_avg_value_idr": 500000000, "fundamental_top_n": 20,
    "fundamental_cache_hours": 168, "target_per": 12.0, "target_pbv": 1.5,
    "technical_weight": 0.70, "fundamental_weight": 0.30
}
for k, v in DEFAULTS.items():
    CFG.setdefault(k, v)

def now_local():
    return datetime.now(TZ)

def load_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def load_state():
    return load_json(STATE_PATH, {})

def save_state(state):
    save_json(STATE_PATH, state)

def recursive_tickers(obj):
    found = set()
    if isinstance(obj, dict):
        keys = {str(k).lower(): k for k in obj}
        code_key = next((keys[k] for k in ("kodeemiten", "code", "ticker", "symbol") if k in keys), None)
        if code_key:
            code = str(obj.get(code_key, "")).strip().upper()
            is_stock = obj.get("EfekEmiten_Saham", obj.get("efekEmiten_Saham", True))
            status = str(obj.get("Status", obj.get("status", "0"))).lower()
            if re.fullmatch(r"[A-Z]{4}", code) and is_stock is not False and status not in ("delisted", "inactive"):
                found.add(code)
        for v in obj.values():
            found |= recursive_tickers(v)
    elif isinstance(obj, list):
        for v in obj:
            found |= recursive_tickers(v)
    return found

def get_universe():
    url = CFG.get("universe_url", "").strip()
    headers = {"User-Agent": "Mozilla/5.0 BEI-Auto-Scanner/2.0",
               "Accept": "application/json, text/plain, */*",
               "Referer": "https://www.idx.co.id/id/perusahaan-tercatat/profil-perusahaan/"}
    if url:
        try:
            r = requests.get(url, headers=headers, timeout=25)
            r.raise_for_status()
            tickers = sorted(recursive_tickers(r.json()))
            if len(tickers) >= 100:
                return tickers[:int(CFG["max_tickers"])], "IDX"
            print(f"Endpoint IDX hanya mengembalikan {len(tickers)} ticker; belum dianggap universe penuh.")
        except Exception as exc:
            print(f"Pengambilan universe IDX gagal: {exc}")
    fallback_path = ROOT / "tickers_fallback.txt"
    fallback = []
    if fallback_path.exists():
        fallback = [x.strip().upper() for x in fallback_path.read_text(encoding="utf-8").splitlines()
                    if x.strip() and not x.strip().startswith("#")]
    fallback = sorted(set(x for x in fallback if re.fullmatch(r"[A-Z]{4}", x)))
    if len(fallback) < 100:
        raise RuntimeError("Universe BEI tidak tersedia: endpoint IDX gagal/tidak lengkap dan fallback kurang dari 100 ticker. Scanner berhenti agar tidak mengaku memindai seluruh BEI.")
    return fallback[:int(CFG["max_tickers"])], "fallback"

def normalize_yf_frame(raw, ticker):
    if raw is None or raw.empty:
        return None
    if isinstance(raw.columns, pd.MultiIndex):
        if ticker in raw.columns.get_level_values(0):
            df = raw[ticker].copy()
        elif ticker in raw.columns.get_level_values(-1):
            df = raw.xs(ticker, axis=1, level=-1).copy()
        else:
            return None
    else:
        df = raw.copy()
    df.columns = [str(c).lower().replace(" ", "_") for c in df.columns]
    required = ["open", "high", "low", "close", "volume"]
    if not set(required).issubset(df.columns):
        return None
    df = df[required].copy()
    for col in required:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["close", "volume"])
    return df if not df.empty else None

def fetch_intraday(tickers):
    symbols = [t + ".JK" for t in tickers]
    results = {}
    batch_size = int(CFG["batch_size"])
    for start in range(0, len(symbols), batch_size):
        batch = symbols[start:start + batch_size]
        try:
            raw = yf.download(tickers=batch, period="5d", interval="5m",
                              group_by="ticker", auto_adjust=False, threads=False,
                              progress=False, prepost=False, timeout=30)
            for symbol in batch:
                frame = normalize_yf_frame(raw, symbol)
                if frame is not None and len(frame) >= 55:
                    results[symbol[:-3]] = frame
        except Exception as exc:
            print(f"Batch {start // batch_size + 1} gagal: {exc}")
        time.sleep(1.0)
    return results

def _local_index(index):
    idx = pd.DatetimeIndex(pd.to_datetime(index))
    if idx.tz is not None:
        return idx.tz_convert(TZ)
    # yfinance intraday timestamps biasanya timezone-aware; jika tidak, diasumsikan WIB.
    return idx.tz_localize(TZ)

def calculate_rsi(close, period=14):
    delta = close.diff()
    gain = delta.clip(lower=0).rolling(period, min_periods=period).mean()
    loss = (-delta.clip(upper=0)).rolling(period, min_periods=period).mean()
    out = pd.Series(np.nan, index=close.index, dtype=float)
    normal = loss > 0
    out.loc[normal] = 100 - (100 / (1 + gain.loc[normal] / loss.loc[normal]))
    out.loc[(loss == 0) & (gain > 0)] = 100
    out.loc[(loss == 0) & (gain == 0)] = 50
    return out

def calculate_rvol(df, local_idx):
    # Bandingkan candle terakhir dengan candle pada jam/menit yang sama di sesi sebelumnya.
    last_time = local_idx[-1]
    prior = []
    for i in range(len(df) - 1):
        ts = local_idx[i]
        if ts.date() != last_time.date() and ts.hour == last_time.hour and ts.minute == last_time.minute:
            prior.append(float(df["volume"].iloc[i]))
    if len(prior) >= 2:
        base = float(np.mean(prior[-5:]))
        return float(df["volume"].iloc[-1] / base) if base > 0 else 0.0, "same_time"
    base = float(df["volume"].iloc[-21:-1].mean()) if len(df) >= 21 else 0.0
    return (float(df["volume"].iloc[-1] / base) if base > 0 else 0.0), "rolling_fallback"

def score_one(code, frame):
    df = frame.copy().sort_index()
    df = df[~df.index.duplicated(keep="last")]
    for c in ("open", "high", "low", "close", "volume"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["close", "volume"])
    if len(df) < 55:
        return None

    close, high, low, vol = df.close, df.high, df.low, df.volume
    last, prev_bar = float(close.iloc[-1]), float(close.iloc[-2])
    if not np.isfinite(last) or last <= 0:
        return None

    ma5 = float(close.rolling(5).mean().iloc[-1])
    ma20 = float(close.rolling(20).mean().iloc[-1])
    ma50 = float(close.rolling(50).mean().iloc[-1])
    rsi_series = calculate_rsi(close)
    rsi = float(rsi_series.iloc[-1]) if pd.notna(rsi_series.iloc[-1]) else 50.0

    local_idx = _local_index(df.index)
    latest_date = local_idx[-1].date()
    session_mask = np.array([x.date() == latest_date for x in local_idx])
    session = df.loc[session_mask]
    previous_sessions = df.loc[~session_mask]
    prev_close = float(previous_sessions.close.iloc[-1]) if not previous_sessions.empty else prev_bar
    typical = (session.high + session.low + session.close) / 3
    volume_sum = float(session.volume.sum())
    vwap = float((typical * session.volume).sum() / volume_sum) if volume_sum > 0 else last

    rvol, rvol_method = calculate_rvol(df, local_idx)
    avg_value = float((close * vol).iloc[-20:].mean())
    recent_high = float(high.iloc[-21:-1].max())
    recent_low = float(low.iloc[-21:-1].min())
    change_pct = (last / prev_close - 1) * 100 if prev_close else 0.0

    score, reasons = 0, []
    if ma5 > ma20: score += 10; reasons.append("MA5 di atas MA20")
    if ma20 > ma50: score += 10; reasons.append("MA20 di atas MA50")
    if last > ma20: score += 5
    if last > vwap: score += 10; reasons.append("harga di atas VWAP")
    if rvol >= 1.5: score += 15; reasons.append(f"RVOL {rvol:.1f}x")
    elif rvol >= 1.2: score += 8; reasons.append(f"RVOL {rvol:.1f}x")
    if 50 <= rsi <= 70: score += 10; reasons.append(f"RSI {rsi:.0f}")
    elif 45 <= rsi < 50: score += 5
    if last > recent_high: score += 20; reasons.append("breakout high 20 bar")
    elif last > recent_low * 1.015 and last > ma5: score += 10; reasons.append("momentum/pullback pulih")
    if change_pct > 0: score += 5
    if avg_value >= float(CFG["min_avg_value_idr"]): score += 15; reasons.append("likuiditas lolos")
    elif avg_value >= float(CFG["min_avg_value_idr"]) * 0.5: score += 7

    if last < float(CFG["min_price_idr"]): return None
    if avg_value < float(CFG["min_avg_value_idr"]) * 0.5: return None
    if rsi >= 78 or rsi < 35: return None

    bar_range = float((high - low).rolling(14).mean().iloc[-1])
    if not np.isfinite(bar_range) or bar_range <= 0:
        bar_range = last * 0.01
    risk_unit = max(bar_range, last * 0.007)
    return {
        "ticker": code, "price": last, "technical_score": int(min(score, 100)),
        "score": int(min(score, 100)), "rsi": rsi, "rvol": rvol,
        "rvol_method": rvol_method, "ma5": ma5, "ma20": ma20, "ma50": ma50,
        "vwap": vwap, "avg_value": avg_value, "change_pct": change_pct,
        "entry_low": last, "entry_high": last + max(last * .002, risk_unit * .15),
        "sl": max(0, last - risk_unit), "tp1": last + risk_unit * 1.5,
        "tp2": last + risk_unit * 2.2, "reasons": reasons,
        "fundamental_available": False
    }

def _num(info, key):
    try:
        v = float(info.get(key))
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None

def fundamental_one(code, current_price=None):
    cache = load_json(FUND_CACHE_PATH, {})
    now = time.time()
    cached = cache.get(code)
    max_age = float(CFG["fundamental_cache_hours"]) * 3600
    if cached and now - float(cached.get("fetched_at", 0)) < max_age:
        return cached.get("data")

    try:
        info = yf.Ticker(code + ".JK").get_info()
    except Exception as exc:
        print(f"Fundamental {code} tidak tersedia: {exc}")
        return None
    if not isinstance(info, dict) or not info:
        return None

    price = current_price or _num(info, "currentPrice") or _num(info, "regularMarketPrice")
    eps = _num(info, "trailingEps")
    book = _num(info, "bookValue")
    per = _num(info, "trailingPE")
    pbv = _num(info, "priceToBook")
    roe = _num(info, "returnOnEquity")
    debt_equity = _num(info, "debtToEquity")
    revenue_growth = _num(info, "revenueGrowth")
    earnings_growth = _num(info, "earningsGrowth")
    dividend_yield = _num(info, "dividendYield")
    operating_cashflow = _num(info, "operatingCashflow")
    free_cashflow = _num(info, "freeCashflow")

    target_per = float(CFG["target_per"])
    target_pbv = float(CFG["target_pbv"])
    per_fair = eps * target_per if eps is not None and eps > 0 else None
    pbv_fair = book * target_pbv if book is not None and book > 0 else None
    fair_values = [v for v in (per_fair, pbv_fair) if v is not None and v > 0]
    fair_value = float(np.mean(fair_values)) if fair_values else None
    upside = ((fair_value / price) - 1) * 100 if fair_value and price and price > 0 else None

    score, factors = 0, []
    count = 0
    if per is not None and per > 0:
        count += 1
        if per <= target_per: score += 20; factors.append("PER relatif rendah")
        elif per <= target_per * 1.5: score += 10; factors.append("PER moderat")
    if pbv is not None and pbv > 0:
        count += 1
        if pbv <= target_pbv: score += 15; factors.append("PBV relatif rendah")
        elif pbv <= target_pbv * 2: score += 7
    if roe is not None:
        count += 1
        if roe >= .15: score += 20; factors.append("ROE kuat")
        elif roe >= .08: score += 10
        elif roe < 0: factors.append("ROE negatif")
    if debt_equity is not None:
        count += 1
        if debt_equity <= 50: score += 15; factors.append("utang relatif terkendali")
        elif debt_equity <= 100: score += 8
    if revenue_growth is not None:
        count += 1
        if revenue_growth >= .10: score += 10; factors.append("pendapatan tumbuh")
        elif revenue_growth > 0: score += 5
    if earnings_growth is not None:
        count += 1
        if earnings_growth >= .10: score += 10; factors.append("laba tumbuh")
        elif earnings_growth > 0: score += 5
    if free_cashflow is not None:
        count += 1
        if free_cashflow > 0: score += 10; factors.append("free cash flow positif")
    if count == 0:
        return None

    result = {
        "ticker": code, "price": price, "eps": eps, "book_value": book,
        "per": per, "pbv": pbv, "roe": roe, "debt_equity": debt_equity,
        "revenue_growth": revenue_growth, "earnings_growth": earnings_growth,
        "dividend_yield": dividend_yield, "operating_cashflow": operating_cashflow,
        "free_cashflow": free_cashflow, "per_fair": per_fair, "pbv_fair": pbv_fair,
        "fair_value": fair_value, "upside_pct": upside,
        "fundamental_score": int(min(score, 100)), "data_fields": count,
        "factors": factors, "source": "Yahoo Finance (field availability varies)"
    }
    cache[code] = {"fetched_at": now, "data": result}
    save_json(FUND_CACHE_PATH, cache)
    return result

def enrich_fundamentals(candidates):
    # Batasi jumlah permintaan data fundamental agar tetap ringan dan tidak membebani sumber gratis.
    for row in candidates[:int(CFG["fundamental_top_n"])]:
        f = fundamental_one(row["ticker"], row["price"])
        if f:
            row["fundamental"] = f
            row["fundamental_available"] = True
            row["fundamental_score"] = f["fundamental_score"]
            tw = float(CFG["technical_weight"])
            fw = float(CFG["fundamental_weight"])
            row["score"] = int(round(row["technical_score"] * tw + f["fundamental_score"] * fw))
        else:
            row["fundamental"] = None
            row["fundamental_available"] = False
            row["score"] = row["technical_score"]
    return candidates

def fmt_price(x):
    return "N/A" if x is None else f"Rp{int(round(x)):,}".replace(",", ".")

def fmt_ratio_pct(x):
    """Format Yahoo ratio fields (e.g. ROE=0.15) as percentages."""
    return "N/A" if x is None else f"{x * 100:.1f}%"

def fmt_pct(x):
    """Format values that are already expressed in percentage points."""
    return "N/A" if x is None else f"{x:.1f}%"

def run_scan(enrich=True, mode="regular"):
    stamp = now_local()
    tickers, source = get_universe()
    data = fetch_intraday(tickers)
    candidates = []
    data_timestamps = []
    stale_count = 0
    max_age = float(CFG.get("max_live_data_age_minutes", 45))
    allow_stale = mode in ("morning_top10", "preopen")
    for code, frame in data.items():
        try:
            local_idx = _local_index(frame.index)
            latest_bar = local_idx[-1]
            data_timestamps.append(latest_bar)
            age_minutes = max(0.0, (stamp - latest_bar.to_pydatetime()).total_seconds() / 60.0)
            if not allow_stale and age_minutes > max_age:
                stale_count += 1
                continue
            row = score_one(code, frame)
            if row and row["technical_score"] >= int(CFG["min_score"]):
                row["data_time"] = latest_bar.strftime("%d-%m-%Y %H:%M WIB")
                row["data_age_minutes"] = round(age_minutes, 1)
                candidates.append(row)
        except Exception as exc:
            print(f"Analisis teknikal {code} gagal: {exc}")
    candidates.sort(key=lambda x: (x["technical_score"], x["rvol"], x["avg_value"]), reverse=True)
    candidates = candidates[:max(int(CFG["max_alerts"]) * 3, int(CFG["fundamental_top_n"]))]
    if enrich:
        candidates = enrich_fundamentals(candidates)
    candidates.sort(key=lambda x: (x["score"], x["technical_score"], x["rvol"], x["avg_value"]), reverse=True)
    latest_market_data = max(data_timestamps).to_pydatetime() if data_timestamps else None
    latest_market_data_text = latest_market_data.strftime("%d-%m-%Y %H:%M WIB") if latest_market_data else "Tidak tersedia"
    return {"stamp": stamp, "universe_count": len(tickers), "data_count": len(data),
            "stale_count": stale_count, "latest_market_data": latest_market_data_text,
            "source": source, "mode": mode,
            "candidates": candidates[:int(CFG["max_alerts"])]}

def fundamental_report(code):
    code = code.strip().upper()
    if not re.fullmatch(r"[A-Z]{4}", code):
        return "Format kode saham tidak valid. Contoh: /fundamental BBCA"
    f = fundamental_one(code)
    if not f:
        return f"Data fundamental {code} tidak tersedia atau tidak cukup di Yahoo Finance. Tidak dibuat estimasi harga wajar."
    lines = [f"📚 FUNDAMENTAL {code}", f"PER: {f['per']:.2f}" if f["per"] is not None else "PER: N/A",
             f"PBV: {f['pbv']:.2f}" if f["pbv"] is not None else "PBV: N/A",
             f"ROE: {fmt_ratio_pct(f['roe'])}", f"Debt/Equity: {f['debt_equity']:.1f}" if f["debt_equity"] is not None else "Debt/Equity: N/A",
             f"Pertumbuhan pendapatan: {fmt_ratio_pct(f['revenue_growth'])}",
             f"Pertumbuhan laba: {fmt_ratio_pct(f['earnings_growth'])}",
             f"Dividend yield: {fmt_ratio_pct(f['dividend_yield'])}",
             f"Estimasi PER: {fmt_price(f['per_fair'])}",
             f"Estimasi PBV: {fmt_price(f['pbv_fair'])}",
             f"Estimasi nilai wajar gabungan: {fmt_price(f['fair_value'])}",
             f"Upside/downside indikatif: {fmt_pct(f['upside_pct'])}",
             f"Skor fundamental: {f['fundamental_score']}/100",
             "", "Catatan: target PER/PBV adalah asumsi konfigurasi, bukan nilai intrinsik pasti. Perlu pembandingan sektor dan pemeriksaan laporan keuangan."]
    return "\n".join(lines)

def candidate_message(title, result):
    lines = [f"📊 {title} — BEI AUTO SCANNER",
             f"Waktu proses: {result['stamp'].strftime('%d-%m-%Y %H:%M WIB')}",
             f"Candle terbaru tersedia: {result.get('latest_market_data', 'Tidak tersedia')}",
             f"Universe: {result['universe_count']} | Data intraday: {result['data_count']} | Data basi dilewati: {result.get('stale_count', 0)} | Sumber: {result['source']}",
             "Skor gabungan: 70% teknikal + 30% fundamental jika data tersedia; tanpa data fundamental, skor teknikal dipakai.",
             "Data Yahoo Finance bukan order book dan tidak dijamin real-time. Skor bukan probabilitas profit."]
    if not result["candidates"]:
        lines.append("Belum ada kandidat yang memenuhi filter teknikal.")
    for i, c in enumerate(result["candidates"], 1):
        lines += ["", f"{i}. {c['ticker']} | Skor {c['score']}/100 (teknikal {c['technical_score']})",
                  f"Harga {fmt_price(c['price'])} ({c['change_pct']:+.2f}%) | RSI {c['rsi']:.1f} | RVOL {c['rvol']:.2f}x",
                  f"Waktu candle saham: {c.get('data_time', 'N/A')} | Umur data: {c.get('data_age_minutes', 'N/A')} menit",
                  f"Entry pantau {fmt_price(c['entry_low'])}–{fmt_price(c['entry_high'])} | TP1 {fmt_price(c['tp1'])} | TP2 {fmt_price(c['tp2'])} | SL {fmt_price(c['sl'])}"]
        f = c.get("fundamental")
        if f:
            lines.append(f"PER {f['per']:.1f}" if f["per"] is not None else "PER N/A")
            lines.append(f"PBV {f['pbv']:.2f}" if f["pbv"] is not None else "PBV N/A")
            lines.append(f"Estimasi wajar PER/PBV {fmt_price(f['fair_value'])} | upside {fmt_pct(f['upside_pct'])}")
        else:
            lines.append("Fundamental: data tidak tersedia; skor teknikal saja.")
        lines.append("Alasan: " + ", ".join(c["reasons"][:4]))
    return "\n".join(lines)

def main():
    mode = os.getenv("SCAN_MODE", "regular").strip().lower()
    if mode not in ("regular", "morning_top10", "preopen", "momentum"):
        mode = "regular"
    result = run_scan(enrich=True, mode=mode)
    titles = {
        "regular": "PEMINDAIAN OTOMATIS 20 MENIT",
        "morning_top10": "TOP 10 WATCHLIST PAGI (INDIKATIF)",
        "preopen": "PEMINDAIAN PRA-PEMBUKAAN 08.40 WIB (INDIKATIF)",
        "momentum": "ALERT MOMENTUM 09.15 WIB"
    }
    if mode == "momentum":
        result["candidates"] = [c for c in result["candidates"]
            if c["rvol"] >= 1.2 and (c["price"] > c["vwap"])
            and any("breakout" in r.lower() or "momentum" in r.lower() for r in c["reasons"])]
    message = candidate_message(titles[mode], result)
    if mode in ("morning_top10", "preopen", "momentum"):
        telegram_send(message)
        return
    if not result["candidates"]:
        print(message)
        return
    stamp = result["stamp"]
    state = load_state()
    today = stamp.strftime("%Y-%m-%d")
    sent = []
    for c in result["candidates"]:
        key = f"{today}:{c['ticker']}"
        old = int(state.get(key, 0))
        if old == 0 or c["score"] >= old + 10:
            sent.append(c)
            state[key] = c["score"]
    if sent:
        slim = dict(result)
        slim["candidates"] = sent
        telegram_send(candidate_message(titles[mode], slim))
        save_state(state)
    else:
        print("Kandidat ada, tetapi belum ada peningkatan skor 10 poin untuk notifikasi.")

def telegram_send(message):
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        print("Telegram belum dikonfigurasi; hasil hanya tampil di log.")
        print(message)
        return
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    response = requests.post(url, json={"chat_id": chat_id, "text": str(message)[:3900],
                                        "disable_web_page_preview": True}, timeout=25)
    response.raise_for_status()
    body = response.json()
    if not body.get("ok"):
        raise RuntimeError(f"Telegram sendMessage gagal: {body}")

if __name__ == "__main__":
    main()
