# BEI Auto Scanner — Final Free Edition

## Fitur
- Pemindaian saham BEI dengan daftar emiten dari endpoint profil perusahaan IDX; jika endpoint gagal, paket hanya memiliki fallback contoh 20 saham dan scanner akan berhenti. Karena itu fallback tidak diklaim sebagai seluruh BEI.
- Data intraday gratis Yahoo Finance 5 menit; bukan data order book/running trade dan tidak dijamin real-time.
- Indikator MA5/MA20/MA50, RSI, VWAP, RVOL, breakout/pullback, likuiditas, ATR/range, level entry/TP/SL indikatif.
- Overlay fundamental opsional untuk kandidat teratas: PER, PBV, ROE, utang, pertumbuhan, arus kas dan estimasi PER/PBV sederhana. Bukan DCF atau nilai intrinsik pasti.
- Notifikasi Telegram dan perintah interaktif.
- Semua transaksi tetap manual; bot tidak terhubung ke broker.

## Jadwal WIB
- 06.00: Top 10 watchlist pagi (indikatif; bisa memakai candle sesi sebelumnya).
- 08.40: pemindaian pra-pembukaan (indikatif; data pra-pasar bisa belum tersedia).
- 09.15: alert momentum; kandidat disaring dari data yang tersedia dan data live yang terlalu lama dibuang.
- 09.00–15.40: pemindaian rutin setiap 20 menit, Senin–Jumat.
- 09.00–15.55: pemeriksaan perintah Telegram setiap 5 menit, Senin–Jumat.

GitHub Actions menggunakan UTC dan dapat menunda/melewatkan jadwal. Ini bukan server 24 jam atau jaminan respons tepat waktu.

## File
- `scanner.py`: mesin pemindaian.
- `command_bot.py`: handler perintah Telegram.
- `config.json`: konfigurasi aktif dengan endpoint IDX yang sebelumnya digunakan.
- `tickers_fallback.txt`: fallback contoh 20 ticker, bukan universe lengkap.
- `.github/workflows/scanner.yml`: jadwal scanner.
- `.github/workflows/bot_commands.yml`: polling perintah.
- `data/`: state alert, cache fundamental, dan offset Telegram.

## Instalasi melalui iPhone
1. Buka repository GitHub `bei-auto-scanner-free`.
2. Cadangkan file lama sebelum mengganti.
3. Unggah seluruh isi folder paket ke root repository, pertahankan struktur `.github/workflows/` dan `data/`.
4. Pastikan GitHub Secrets `TELEGRAM_BOT_TOKEN` dan `TELEGRAM_CHAT_ID` sudah terisi. Jangan menaruh token dalam kode atau file ZIP.
5. Pastikan Actions diizinkan dan workflow memiliki izin `contents: write`.
6. Buka Actions, jalankan `Telegram Command Bot` secara manual, lalu kirim `/start`.
7. Jalankan `BEI Auto Scanner` secara manual dengan mode `regular` untuk uji awal.

## Perintah Telegram
- `/start`, `/help`
- `/status`
- `/scan`
- `/top10`
- `/breakout`
- `/momentum`
- `/pullback`
- `/fundamental BBCA`

## Keterbatasan penting
- Endpoint IDX dapat berubah atau membatasi akses. Jika gagal, fallback 20 saham tidak memenuhi cakupan seluruh BEI dan scanner berhenti dengan pesan error.
- Yahoo Finance gratis dapat terlambat, tidak lengkap, atau tidak menyediakan seluruh ticker. Timestamp candle ditampilkan; mode live mengabaikan data yang lebih tua dari batas konfigurasi 45 menit.
- Pukul 06.00 dan 08.40 WIB, data intraday dapat berasal dari sesi sebelumnya; hasil diberi label indikatif dan bukan sinyal harga pembukaan.
- Nilai wajar fundamental hanya rata-rata pendekatan EPS×target PER dan book value×target PBV jika datanya tersedia. Periksa laporan keuangan resmi, kualitas laba, utang, arus kas, dan karakteristik sektor.
- Entry/TP/SL hanya estimasi berbasis volatilitas candle; tidak memperhitungkan spread, slippage, antrean, ARA/ARB, atau order book.
- Skor bukan probabilitas profit. Uji paper trading sebelum dipakai untuk keputusan transaksi.
