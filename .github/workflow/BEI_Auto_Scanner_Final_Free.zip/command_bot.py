import os, json, traceback
from pathlib import Path
import requests
import scanner

ROOT = Path(__file__).resolve().parent
OFFSET_PATH = ROOT / "data" / "telegram_offset.json"
API = "https://api.telegram.org/bot{}/{}"

def credentials():
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        raise RuntimeError("GitHub Secrets TELEGRAM_BOT_TOKEN dan TELEGRAM_CHAT_ID wajib tersedia.")
    return token, str(chat_id)

def call(token, method, payload=None, params=None):
    url = API.format(token, method)
    r = requests.post(url, json=payload, timeout=30) if payload is not None else requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    body = r.json()
    if not body.get("ok"):
        raise RuntimeError(f"Telegram API {method}: {body}")
    return body.get("result")

def send(token, chat_id, message):
    text = str(message)
    while text:
        part = text[:3900]
        if len(text) > 3900:
            cut = part.rfind("\n")
            if cut > 1000: part = part[:cut]
        call(token, "sendMessage", {"chat_id": chat_id, "text": part, "disable_web_page_preview": True})
        text = text[len(part):].lstrip("\n")

def load_offset():
    try: return int(json.loads(OFFSET_PATH.read_text(encoding="utf-8")).get("offset", 0))
    except Exception: return 0

def save_offset(value):
    OFFSET_PATH.parent.mkdir(parents=True, exist_ok=True)
    OFFSET_PATH.write_text(json.dumps({"offset": int(value)}, indent=2), encoding="utf-8")

def help_text():
    return ("🤖 BEI AUTO SCANNER\n\n"
      "/start atau /help — bantuan\n/status — status jadwal\n"
      "/scan — pemindaian baru\n/top10 — 10 kandidat teratas\n"
      "/breakout — kandidat breakout\n/momentum — kandidat momentum\n"
      "/pullback — kandidat pullback/pemulihan\n/fundamental BBCA — ringkasan fundamental\n\n"
      "Otomatis: Top 10 pukul 06.00, pra-pembukaan 08.40, momentum 09.15, dan scan setiap 20 menit pada hari bursa. Polling perintah sekitar setiap 5 menit pada jam kerja.")

def execute(token, chat_id, command, args):
    if command in ("/start", "/help"):
        send(token, chat_id, help_text())
    elif command == "/status":
        send(token, chat_id, "🟢 Konfigurasi jadwal: Top 10 06.00 WIB; pra-pembukaan 08.40 WIB; momentum 09.15 WIB; pemindaian rutin setiap 20 menit. Polling perintah setiap 5 menit. GitHub Actions dapat terlambat. Yahoo Finance bukan data order book dan tidak dijamin real-time.")
    elif command in ("/scan", "/top10", "/breakout", "/momentum", "/pullback"):
        send(token, chat_id, "⏳ Perintah diterima. Pemindaian baru sedang dijalankan; proses dapat memerlukan beberapa menit.")
        result = scanner.run_scan(enrich=True, mode="regular")
        rows = result["candidates"]
        if command == "/breakout":
            rows = [c for c in rows if any("breakout" in x.lower() for x in c["reasons"])]
        elif command == "/momentum":
            rows = [c for c in rows if c["rvol"] >= 1.2 and c["price"] > c["vwap"]]
        elif command == "/pullback":
            rows = [c for c in rows if any("pullback" in x.lower() or "pulih" in x.lower() for x in c["reasons"])]
        result["candidates"] = rows[:10]
        labels = {"/scan":"HASIL PEMINDAIAN MANUAL", "/top10":"TOP 10 KANDIDAT", "/breakout":"KANDIDAT BREAKOUT", "/momentum":"KANDIDAT MOMENTUM", "/pullback":"KANDIDAT PULLBACK"}
        send(token, chat_id, scanner.candidate_message(labels[command], result))
    elif command == "/fundamental":
        if not args: send(token, chat_id, "Format: /fundamental BBCA")
        else: send(token, chat_id, scanner.fundamental_report(args[0]))
    else:
        send(token, chat_id, "Perintah tidak dikenal. Gunakan /help.")

def main():
    token, allowed_chat_id = credentials()
    offset = load_offset()
    updates = call(token, "getUpdates", params={"offset": offset, "timeout": 0,
                  "allowed_updates": json.dumps(["message"])}) or []
    last_successful = offset - 1
    for update in updates:
        update_id = int(update["update_id"])
        msg = update.get("message") or {}
        chat = msg.get("chat") or {}
        sender = msg.get("from") or {}
        actual_chat = str(chat.get("id", ""))
        if actual_chat != allowed_chat_id or sender.get("is_bot"):
            last_successful = update_id
            continue
        text = (msg.get("text") or "").strip()
        if not text.startswith("/"):
            last_successful = update_id
            continue
        parts = text.split()
        command = parts[0].split("@")[0].lower()
        try:
            execute(token, allowed_chat_id, command, parts[1:])
            last_successful = update_id
        except Exception as exc:
            print(f"Perintah {command} gagal: {exc}")
            traceback.print_exc()
            try: send(token, allowed_chat_id, f"⚠️ Perintah gagal: {str(exc)[:350]}")
            except Exception: pass
            break
    if last_successful >= offset: save_offset(last_successful + 1)
    print(f"Update masuk: {len(updates)}; offset tersimpan: {load_offset()}")

if __name__ == "__main__": main()
