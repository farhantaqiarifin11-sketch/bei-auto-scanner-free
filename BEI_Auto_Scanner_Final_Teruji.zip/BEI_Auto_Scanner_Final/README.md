# BEI Auto Scanner Free — paket final perbaikan

## Isi paket
- `scanner.py`: pemindaian terjadwal, scoring teknikal, filter likuiditas/harga, level risiko, jurnal sinyal, evaluasi sinyal.
- `technical_engine.py`, `risk_management.py`, `fundamental_engine.py`, `signal_evaluation.py`: modul analisis.
- `bot_commands.py`: polling dan perintah Telegram.
- `.github/workflows/scan.yml`: jadwal pemindaian.
- `.github/workflows/telegram_commands.yml`: polling Telegram 10 menit.

## Instalasi GitHub
1. Ekstrak ZIP, lalu unggah **seluruh isi folder** `BEI_Auto_Scanner_Final` ke root repository GitHub (folder `.github` harus berada di root).
2. Hapus file workflow lama yang duplikat agar tidak ada pemindaian/polling ganda.
3. Repository Settings → Secrets and variables → Actions: buat `TELEGRAM_BOT_TOKEN` dan `TELEGRAM_CHAT_ID`.
4. Settings → Actions → General → Workflow permissions: pilih **Read and write permissions**.
5. Jalankan workflow `BEI Auto Scanner` melalui Actions → Run workflow. Polling Telegram berjalan terjadwal setiap 10 menit.

## Perintah Telegram
`/start`, `/help`, `/status`, `/scan`, `/top10`, `/analyze BBCA`, `/watchlist`, `/add BBCA`, `/remove BBCA`, `/performance`.

## Jadwal WIB (Senin–Jumat)
- 06:00 Top 10
- 08:40 pemindaian pra-pasar sesuai jadwal yang dikonfigurasi
- 09:15 momentum
- 09:00–15:40 pemindaian rutin setiap 20 menit
- Polling perintah Telegram setiap 10 menit selama rentang workflow aktif

## Batasan data yang wajib dipahami
- Harga diambil dari Yahoo Finance interval 5 menit, bukan feed BEI real-time dan tidak menyediakan orderbook.
- Universe mencoba CSV lokal lalu endpoint IDX. Jika keduanya gagal, sistem memakai **fallback parsial 20 saham** dan menandainya di pesan Telegram; ini bukan cakupan seluruh emiten BEI. Untuk cakupan luas, isi `data/universe/idx-tickers.csv` dengan daftar ticker valid terbaru (kolom `ticker`).
- Fundamental Yahoo Finance bersifat best-effort; data kosong tidak dianggap nol dan bukan pengganti laporan keuangan resmi.
- GitHub Actions terjadwal tidak menjamin eksekusi tepat pada menit yang ditentukan. Polling 10 menit juga bukan bot 24/7.
- Skor teknikal belum merupakan probabilitas profit dan seluruh entry/SL/TP bersifat estimasi. Evaluasi jurnal sederhana, bukan backtest profesional.
- Uji terlebih dahulu dengan paper trading.
